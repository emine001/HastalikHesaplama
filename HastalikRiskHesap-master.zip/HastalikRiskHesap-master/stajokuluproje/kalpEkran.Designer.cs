﻿namespace stajokuluproje
{
    partial class KALP_HASTALIĞI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnKadin = new System.Windows.Forms.RadioButton();
            this.btnErkek = new System.Windows.Forms.RadioButton();
            this.btnKiloE = new System.Windows.Forms.RadioButton();
            this.btnKiloH = new System.Windows.Forms.RadioButton();
            this.btnSigaraE = new System.Windows.Forms.RadioButton();
            this.btnSigaraH = new System.Windows.Forms.RadioButton();
            this.btnKalpE = new System.Windows.Forms.RadioButton();
            this.btnKalpH = new System.Windows.Forms.RadioButton();
            this.btnTansiyonE = new System.Windows.Forms.RadioButton();
            this.btnTansiyonH = new System.Windows.Forms.RadioButton();
            this.btnStresE = new System.Windows.Forms.RadioButton();
            this.btnStresH = new System.Windows.Forms.RadioButton();
            this.btnSekerE = new System.Windows.Forms.RadioButton();
            this.btnSekerH = new System.Windows.Forms.RadioButton();
            this.btnYas0 = new System.Windows.Forms.RadioButton();
            this.btnYas1 = new System.Windows.Forms.RadioButton();
            this.btnYas2 = new System.Windows.Forms.RadioButton();
            this.btnSporH = new System.Windows.Forms.RadioButton();
            this.btnSporE = new System.Windows.Forms.RadioButton();
            this.kalpbutton = new System.Windows.Forms.Button();
            this.geriButton = new System.Windows.Forms.Button();
            this.grCinsiyet = new System.Windows.Forms.GroupBox();
            this.grKilo = new System.Windows.Forms.GroupBox();
            this.grYas = new System.Windows.Forms.GroupBox();
            this.grKalpHst = new System.Windows.Forms.GroupBox();
            this.grTansiyonHst = new System.Windows.Forms.GroupBox();
            this.grSekerHst = new System.Windows.Forms.GroupBox();
            this.grStres = new System.Windows.Forms.GroupBox();
            this.grSpor = new System.Windows.Forms.GroupBox();
            this.grSigara = new System.Windows.Forms.GroupBox();
            this.linkButton = new System.Windows.Forms.Button();
            this.grCinsiyet.SuspendLayout();
            this.grKilo.SuspendLayout();
            this.grYas.SuspendLayout();
            this.grKalpHst.SuspendLayout();
            this.grTansiyonHst.SuspendLayout();
            this.grSekerHst.SuspendLayout();
            this.grStres.SuspendLayout();
            this.grSpor.SuspendLayout();
            this.grSigara.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(180, 384);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Şeker Hastalığınız Var Mı?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(179, 317);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(249, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tansiyon Hastalığınız Var Mı? ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(180, 248);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(263, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ailenizde Kalp Hastalığı Var Mı?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(180, 533);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(264, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Düzenli Spor Yapıyor Musunuz?";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(179, 596);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(230, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Sigara Kullanıyor Musunuz?";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(179, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(196, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Kilo Sorununuz Var Mı?";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(180, 460);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(306, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Stresli Ortamda Bulunuyor Musunuz?";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(180, 184);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(195, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Yaş Aralığınızı Seçiniz?";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(180, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(166, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Cinsiyetinizi Seçiniz";
            // 
            // btnKadin
            // 
            this.btnKadin.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btnKadin.AutoSize = true;
            this.btnKadin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKadin.Location = new System.Drawing.Point(124, 19);
            this.btnKadin.Name = "btnKadin";
            this.btnKadin.Size = new System.Drawing.Size(81, 24);
            this.btnKadin.TabIndex = 9;
            this.btnKadin.TabStop = true;
            this.btnKadin.Text = "KADIN";
            this.btnKadin.UseVisualStyleBackColor = true;
            // 
            // btnErkek
            // 
            this.btnErkek.AutoSize = true;
            this.btnErkek.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnErkek.Location = new System.Drawing.Point(317, 19);
            this.btnErkek.Name = "btnErkek";
            this.btnErkek.Size = new System.Drawing.Size(86, 24);
            this.btnErkek.TabIndex = 10;
            this.btnErkek.TabStop = true;
            this.btnErkek.Text = "ERKEK";
            this.btnErkek.UseVisualStyleBackColor = true;
            // 
            // btnKiloE
            // 
            this.btnKiloE.AutoSize = true;
            this.btnKiloE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKiloE.Location = new System.Drawing.Point(127, 18);
            this.btnKiloE.Name = "btnKiloE";
            this.btnKiloE.Size = new System.Drawing.Size(73, 24);
            this.btnKiloE.TabIndex = 11;
            this.btnKiloE.TabStop = true;
            this.btnKiloE.Text = "EVET";
            this.btnKiloE.UseVisualStyleBackColor = true;
            // 
            // btnKiloH
            // 
            this.btnKiloH.AutoSize = true;
            this.btnKiloH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKiloH.Location = new System.Drawing.Point(320, 19);
            this.btnKiloH.Name = "btnKiloH";
            this.btnKiloH.Size = new System.Drawing.Size(83, 24);
            this.btnKiloH.TabIndex = 12;
            this.btnKiloH.TabStop = true;
            this.btnKiloH.Text = "HAYIR";
            this.btnKiloH.UseVisualStyleBackColor = true;
            // 
            // btnSigaraE
            // 
            this.btnSigaraE.AutoSize = true;
            this.btnSigaraE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSigaraE.Location = new System.Drawing.Point(122, 19);
            this.btnSigaraE.Name = "btnSigaraE";
            this.btnSigaraE.Size = new System.Drawing.Size(73, 24);
            this.btnSigaraE.TabIndex = 13;
            this.btnSigaraE.TabStop = true;
            this.btnSigaraE.Text = "EVET";
            this.btnSigaraE.UseVisualStyleBackColor = true;
            // 
            // btnSigaraH
            // 
            this.btnSigaraH.AutoSize = true;
            this.btnSigaraH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSigaraH.Location = new System.Drawing.Point(318, 19);
            this.btnSigaraH.Name = "btnSigaraH";
            this.btnSigaraH.Size = new System.Drawing.Size(83, 24);
            this.btnSigaraH.TabIndex = 14;
            this.btnSigaraH.TabStop = true;
            this.btnSigaraH.Text = "HAYIR";
            this.btnSigaraH.UseVisualStyleBackColor = true;
            // 
            // btnKalpE
            // 
            this.btnKalpE.AutoSize = true;
            this.btnKalpE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKalpE.Location = new System.Drawing.Point(124, 19);
            this.btnKalpE.Name = "btnKalpE";
            this.btnKalpE.Size = new System.Drawing.Size(73, 24);
            this.btnKalpE.TabIndex = 15;
            this.btnKalpE.TabStop = true;
            this.btnKalpE.Text = "EVET";
            this.btnKalpE.UseVisualStyleBackColor = true;
            // 
            // btnKalpH
            // 
            this.btnKalpH.AutoSize = true;
            this.btnKalpH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKalpH.Location = new System.Drawing.Point(320, 19);
            this.btnKalpH.Name = "btnKalpH";
            this.btnKalpH.Size = new System.Drawing.Size(83, 24);
            this.btnKalpH.TabIndex = 16;
            this.btnKalpH.TabStop = true;
            this.btnKalpH.Text = "HAYIR";
            this.btnKalpH.UseVisualStyleBackColor = true;
            // 
            // btnTansiyonE
            // 
            this.btnTansiyonE.AutoSize = true;
            this.btnTansiyonE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTansiyonE.Location = new System.Drawing.Point(122, 19);
            this.btnTansiyonE.Name = "btnTansiyonE";
            this.btnTansiyonE.Size = new System.Drawing.Size(73, 24);
            this.btnTansiyonE.TabIndex = 17;
            this.btnTansiyonE.TabStop = true;
            this.btnTansiyonE.Text = "EVET";
            this.btnTansiyonE.UseVisualStyleBackColor = true;
            // 
            // btnTansiyonH
            // 
            this.btnTansiyonH.AutoSize = true;
            this.btnTansiyonH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTansiyonH.Location = new System.Drawing.Point(318, 19);
            this.btnTansiyonH.Name = "btnTansiyonH";
            this.btnTansiyonH.Size = new System.Drawing.Size(83, 24);
            this.btnTansiyonH.TabIndex = 18;
            this.btnTansiyonH.TabStop = true;
            this.btnTansiyonH.Text = "HAYIR";
            this.btnTansiyonH.UseVisualStyleBackColor = true;
            // 
            // btnStresE
            // 
            this.btnStresE.AutoSize = true;
            this.btnStresE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStresE.Location = new System.Drawing.Point(122, 19);
            this.btnStresE.Name = "btnStresE";
            this.btnStresE.Size = new System.Drawing.Size(73, 24);
            this.btnStresE.TabIndex = 19;
            this.btnStresE.TabStop = true;
            this.btnStresE.Text = "EVET";
            this.btnStresE.UseVisualStyleBackColor = true;
            // 
            // btnStresH
            // 
            this.btnStresH.AutoSize = true;
            this.btnStresH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStresH.Location = new System.Drawing.Point(318, 19);
            this.btnStresH.Name = "btnStresH";
            this.btnStresH.Size = new System.Drawing.Size(83, 24);
            this.btnStresH.TabIndex = 20;
            this.btnStresH.TabStop = true;
            this.btnStresH.Text = "HAYIR";
            this.btnStresH.UseVisualStyleBackColor = true;
            // 
            // btnSekerE
            // 
            this.btnSekerE.AutoSize = true;
            this.btnSekerE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSekerE.Location = new System.Drawing.Point(122, 19);
            this.btnSekerE.Name = "btnSekerE";
            this.btnSekerE.Size = new System.Drawing.Size(73, 24);
            this.btnSekerE.TabIndex = 21;
            this.btnSekerE.TabStop = true;
            this.btnSekerE.Text = "EVET";
            this.btnSekerE.UseVisualStyleBackColor = true;
            // 
            // btnSekerH
            // 
            this.btnSekerH.AutoSize = true;
            this.btnSekerH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSekerH.Location = new System.Drawing.Point(318, 19);
            this.btnSekerH.Name = "btnSekerH";
            this.btnSekerH.Size = new System.Drawing.Size(83, 24);
            this.btnSekerH.TabIndex = 22;
            this.btnSekerH.TabStop = true;
            this.btnSekerH.Text = "HAYIR";
            this.btnSekerH.UseVisualStyleBackColor = true;
            // 
            // btnYas0
            // 
            this.btnYas0.AutoSize = true;
            this.btnYas0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYas0.Location = new System.Drawing.Point(127, 19);
            this.btnYas0.Name = "btnYas0";
            this.btnYas0.Size = new System.Drawing.Size(104, 24);
            this.btnYas0.TabIndex = 23;
            this.btnYas0.TabStop = true;
            this.btnYas0.Text = "0-18 YAŞ";
            this.btnYas0.UseVisualStyleBackColor = true;
            // 
            // btnYas1
            // 
            this.btnYas1.AutoSize = true;
            this.btnYas1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYas1.Location = new System.Drawing.Point(320, 19);
            this.btnYas1.Name = "btnYas1";
            this.btnYas1.Size = new System.Drawing.Size(114, 24);
            this.btnYas1.TabIndex = 24;
            this.btnYas1.TabStop = true;
            this.btnYas1.Text = "18-30 YAŞ";
            this.btnYas1.UseVisualStyleBackColor = true;
            // 
            // btnYas2
            // 
            this.btnYas2.AutoSize = true;
            this.btnYas2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYas2.Location = new System.Drawing.Point(477, 19);
            this.btnYas2.Name = "btnYas2";
            this.btnYas2.Size = new System.Drawing.Size(108, 24);
            this.btnYas2.TabIndex = 25;
            this.btnYas2.TabStop = true;
            this.btnYas2.Text = "30+ YAŞ  ";
            this.btnYas2.UseVisualStyleBackColor = true;
            // 
            // btnSporH
            // 
            this.btnSporH.AutoSize = true;
            this.btnSporH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSporH.Location = new System.Drawing.Point(318, 19);
            this.btnSporH.Name = "btnSporH";
            this.btnSporH.Size = new System.Drawing.Size(83, 24);
            this.btnSporH.TabIndex = 26;
            this.btnSporH.TabStop = true;
            this.btnSporH.Text = "HAYIR";
            this.btnSporH.UseVisualStyleBackColor = true;
            // 
            // btnSporE
            // 
            this.btnSporE.AutoSize = true;
            this.btnSporE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSporE.Location = new System.Drawing.Point(122, 19);
            this.btnSporE.Name = "btnSporE";
            this.btnSporE.Size = new System.Drawing.Size(73, 24);
            this.btnSporE.TabIndex = 27;
            this.btnSporE.TabStop = true;
            this.btnSporE.Text = "EVET";
            this.btnSporE.UseVisualStyleBackColor = true;
            // 
            // kalpbutton
            // 
            this.kalpbutton.BackColor = System.Drawing.Color.PapayaWhip;
            this.kalpbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kalpbutton.Location = new System.Drawing.Point(1068, 671);
            this.kalpbutton.Name = "kalpbutton";
            this.kalpbutton.Size = new System.Drawing.Size(164, 45);
            this.kalpbutton.TabIndex = 28;
            this.kalpbutton.Text = "HESAPLA";
            this.kalpbutton.UseVisualStyleBackColor = false;
            this.kalpbutton.Click += new System.EventHandler(this.hesaplaFunc);
            // 
            // geriButton
            // 
            this.geriButton.BackColor = System.Drawing.Color.PapayaWhip;
            this.geriButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.geriButton.Location = new System.Drawing.Point(1252, 671);
            this.geriButton.Name = "geriButton";
            this.geriButton.Size = new System.Drawing.Size(84, 45);
            this.geriButton.TabIndex = 0;
            this.geriButton.Text = "Geri";
            this.geriButton.UseVisualStyleBackColor = false;
            this.geriButton.Click += new System.EventHandler(this.geriDon);
            // 
            // grCinsiyet
            // 
            this.grCinsiyet.Controls.Add(this.btnKadin);
            this.grCinsiyet.Controls.Add(this.btnErkek);
            this.grCinsiyet.Location = new System.Drawing.Point(489, 39);
            this.grCinsiyet.Name = "grCinsiyet";
            this.grCinsiyet.Size = new System.Drawing.Size(623, 57);
            this.grCinsiyet.TabIndex = 29;
            this.grCinsiyet.TabStop = false;
            // 
            // grKilo
            // 
            this.grKilo.Controls.Add(this.btnKiloH);
            this.grKilo.Controls.Add(this.btnKiloE);
            this.grKilo.Location = new System.Drawing.Point(486, 99);
            this.grKilo.Name = "grKilo";
            this.grKilo.Size = new System.Drawing.Size(623, 57);
            this.grKilo.TabIndex = 30;
            this.grKilo.TabStop = false;
            // 
            // grYas
            // 
            this.grYas.Controls.Add(this.btnYas2);
            this.grYas.Controls.Add(this.btnYas1);
            this.grYas.Controls.Add(this.btnYas0);
            this.grYas.Location = new System.Drawing.Point(486, 161);
            this.grYas.Name = "grYas";
            this.grYas.Size = new System.Drawing.Size(623, 57);
            this.grYas.TabIndex = 30;
            this.grYas.TabStop = false;
            // 
            // grKalpHst
            // 
            this.grKalpHst.Controls.Add(this.btnKalpH);
            this.grKalpHst.Controls.Add(this.btnKalpE);
            this.grKalpHst.Location = new System.Drawing.Point(489, 225);
            this.grKalpHst.Name = "grKalpHst";
            this.grKalpHst.Size = new System.Drawing.Size(623, 57);
            this.grKalpHst.TabIndex = 30;
            this.grKalpHst.TabStop = false;
            // 
            // grTansiyonHst
            // 
            this.grTansiyonHst.Controls.Add(this.btnTansiyonE);
            this.grTansiyonHst.Controls.Add(this.btnTansiyonH);
            this.grTansiyonHst.Location = new System.Drawing.Point(491, 294);
            this.grTansiyonHst.Name = "grTansiyonHst";
            this.grTansiyonHst.Size = new System.Drawing.Size(623, 57);
            this.grTansiyonHst.TabIndex = 30;
            this.grTansiyonHst.TabStop = false;
            // 
            // grSekerHst
            // 
            this.grSekerHst.Controls.Add(this.btnSekerH);
            this.grSekerHst.Controls.Add(this.btnSekerE);
            this.grSekerHst.Location = new System.Drawing.Point(491, 361);
            this.grSekerHst.Name = "grSekerHst";
            this.grSekerHst.Size = new System.Drawing.Size(623, 57);
            this.grSekerHst.TabIndex = 30;
            this.grSekerHst.TabStop = false;
            // 
            // grStres
            // 
            this.grStres.Controls.Add(this.btnStresH);
            this.grStres.Controls.Add(this.btnStresE);
            this.grStres.Location = new System.Drawing.Point(491, 437);
            this.grStres.Name = "grStres";
            this.grStres.Size = new System.Drawing.Size(623, 57);
            this.grStres.TabIndex = 30;
            this.grStres.TabStop = false;
            // 
            // grSpor
            // 
            this.grSpor.Controls.Add(this.btnSporE);
            this.grSpor.Controls.Add(this.btnSporH);
            this.grSpor.Location = new System.Drawing.Point(491, 510);
            this.grSpor.Name = "grSpor";
            this.grSpor.Size = new System.Drawing.Size(623, 57);
            this.grSpor.TabIndex = 30;
            this.grSpor.TabStop = false;
            // 
            // grSigara
            // 
            this.grSigara.Controls.Add(this.btnSigaraE);
            this.grSigara.Controls.Add(this.btnSigaraH);
            this.grSigara.Location = new System.Drawing.Point(491, 573);
            this.grSigara.Name = "grSigara";
            this.grSigara.Size = new System.Drawing.Size(623, 57);
            this.grSigara.TabIndex = 30;
            this.grSigara.TabStop = false;
            // 
            // linkButton
            // 
            this.linkButton.BackColor = System.Drawing.Color.PapayaWhip;
            this.linkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkButton.Location = new System.Drawing.Point(64, 671);
            this.linkButton.Name = "linkButton";
            this.linkButton.Size = new System.Drawing.Size(311, 45);
            this.linkButton.TabIndex = 31;
            this.linkButton.Text = "Online randevu platformu";
            this.linkButton.UseVisualStyleBackColor = false;
            this.linkButton.Click += new System.EventHandler(this.linkOpen);
            // 
            // KALP_HASTALIĞI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.linkButton);
            this.Controls.Add(this.geriButton);
            this.Controls.Add(this.kalpbutton);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grCinsiyet);
            this.Controls.Add(this.grKilo);
            this.Controls.Add(this.grYas);
            this.Controls.Add(this.grKalpHst);
            this.Controls.Add(this.grTansiyonHst);
            this.Controls.Add(this.grSekerHst);
            this.Controls.Add(this.grStres);
            this.Controls.Add(this.grSpor);
            this.Controls.Add(this.grSigara);
            this.Location = new System.Drawing.Point(500, 300);
            this.Name = "KALP_HASTALIĞI";
            this.Text = "KALP_HASTALIĞI";
            this.Load += new System.EventHandler(this.KALP_HASTALIĞI_Load);
            this.grCinsiyet.ResumeLayout(false);
            this.grCinsiyet.PerformLayout();
            this.grKilo.ResumeLayout(false);
            this.grKilo.PerformLayout();
            this.grYas.ResumeLayout(false);
            this.grYas.PerformLayout();
            this.grKalpHst.ResumeLayout(false);
            this.grKalpHst.PerformLayout();
            this.grTansiyonHst.ResumeLayout(false);
            this.grTansiyonHst.PerformLayout();
            this.grSekerHst.ResumeLayout(false);
            this.grSekerHst.PerformLayout();
            this.grStres.ResumeLayout(false);
            this.grStres.PerformLayout();
            this.grSpor.ResumeLayout(false);
            this.grSpor.PerformLayout();
            this.grSigara.ResumeLayout(false);
            this.grSigara.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton btnKadin;
        private System.Windows.Forms.RadioButton btnErkek;
        private System.Windows.Forms.RadioButton btnKiloE;
        private System.Windows.Forms.RadioButton btnKiloH;
        private System.Windows.Forms.RadioButton btnSigaraE;
        private System.Windows.Forms.RadioButton btnSigaraH;
        private System.Windows.Forms.RadioButton btnKalpE;
        private System.Windows.Forms.RadioButton btnKalpH;
        private System.Windows.Forms.RadioButton btnTansiyonE;
        private System.Windows.Forms.RadioButton btnTansiyonH;
        private System.Windows.Forms.RadioButton btnStresE;
        private System.Windows.Forms.RadioButton btnStresH;
        private System.Windows.Forms.RadioButton btnSekerE;
        private System.Windows.Forms.RadioButton btnSekerH;
        private System.Windows.Forms.RadioButton btnYas0;
        private System.Windows.Forms.RadioButton btnYas1;
        private System.Windows.Forms.RadioButton btnYas2;
        private System.Windows.Forms.RadioButton btnSporH;
        private System.Windows.Forms.RadioButton btnSporE;
        private System.Windows.Forms.Button kalpbutton;
        private System.Windows.Forms.Button geriButton;
        private System.Windows.Forms.GroupBox grCinsiyet;
        private System.Windows.Forms.GroupBox grKilo;
        private System.Windows.Forms.GroupBox grYas;
        private System.Windows.Forms.GroupBox grKalpHst;
        private System.Windows.Forms.GroupBox grTansiyonHst;
        private System.Windows.Forms.GroupBox grSekerHst;
        private System.Windows.Forms.GroupBox grStres;
        private System.Windows.Forms.GroupBox grSpor;
        private System.Windows.Forms.GroupBox grSigara;
        private System.Windows.Forms.Button linkButton;
    }
}