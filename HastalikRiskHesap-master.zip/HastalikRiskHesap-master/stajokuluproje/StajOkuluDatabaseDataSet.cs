﻿namespace stajokuluproje
{


    partial class StajOkuluDatabaseDataSet
    {
        partial class KalpHastaligiDataTable
        {
        }
    }
}
